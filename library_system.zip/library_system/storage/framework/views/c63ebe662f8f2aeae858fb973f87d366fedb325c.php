<?php $__env->startSection('title', 'Books'); ?>
<?php $__env->startSection('content'); ?>
        <!-- card -->
        <div class="card my-5">
            <!-- card-body -->
            <div class="card-body">
                <!-- <h5 class="text-center">List of Books</h5> -->
                
                <?php if(Session::has("success_message")): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><?php echo e(Session::get("success_message")); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e($error); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <!-- tab -->
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#booksListPanel" role="tab" aria-controls="bookslist" aria-selected="true">List of Books</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#booksBorrowedPanel" role="tab" aria-controls="booksborrowed" aria-selected="false">Borrowed Books</a>
                    </li>
                </ul>
                <!-- end of tab -->

                <!-- tab content -->
                <div class="tab-content" id="myTabContent">
                    <!-- list of books panel -->
                    <div class="tab-pane fade show active" id="booksListPanel" role="tabpanel" aria-labelledby="bookslist-tab">
                                                
                        <!-- booklist table -->
                        <table id="booklistTable" class="table table-striped table-bordered table-dark text-center">
                            <thead>
                                <tr>
                                    <th colspan="7">
                                        <h2>List of Books</h2>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="6">
                                        <input type="text" class="form-control" id="search" name="search" placeholder="Search: Title, Author or Library Section" />
                                    </th>
                                </tr>
                                <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>Genre</th>
                                    <th>Library Section</th>
                                    <?php if(Auth::user()->role_id == 1): ?>
                                        <th>Book Status</th>
                                    <?php endif; ?>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($books) > 0): ?>
                                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td data-id="t<?php echo e($book->id); ?>"><?php echo e($book->title); ?></td>
                                            <td data-id="a<?php echo e($book->id); ?>"><?php echo e($book->author); ?></td>
                                            <td data-id="g<?php echo e($book->id); ?>"><?php echo e($book->genre->genre); ?></td>
                                            <td data-id="sec<?php echo e($book->id); ?>"><?php echo e($book->section->section); ?></td>
                                            <?php if(Auth::user()->role_id == 1): ?>
                                                <td><?php echo e($book->status->status); ?></td>
                                            <?php endif; ?>
                                            <td>
                                                <?php if(Auth::user()->role_id == 1): ?>                                  
                                                    <button class="btn btn-primary mr-2" onclick="openEditModal(<?php echo e($book->id); ?>, <?php echo e($book->genre_id); ?>, <?php echo e($book->section_id); ?>, <?php echo e($book->status_id); ?>)">
                                                        <i class="fas fa-edit"></i>
                                                    </button>

                                                    <button class="btn btn-danger" onclick="openDeleteModal(<?php echo e($book->id); ?>)">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-primary" onclick='openBorrowModal(<?php echo e($book->id); ?>)'>
                                                        Borrow
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <?php if(Auth::user()->role_id == 1): ?>
                                            <td colspan="7">No record found</td>
                                        <?php else: ?>
                                            <td colspan="5">No record found</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endif; ?>
                                
                            </tbody>                            
                            
                        </table>

                        <div>
                            <?php echo e($books->links()); ?>

                        </div>
                        <!-- end of booklist table -->

                        <?php if(Auth::user()->role_id == 1): ?>
                            <div class="text-right">
                                <button id="btnAddBook" class="btn btn-primary" data-toggle="modal" data-target="#addBookModal"><i class="fas fa-plus-circle"></i> Add New Book</button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- end of list of books panel -->
                    

                    <!-- borrowed books panel -->
                    <div class="tab-pane fade" id="booksBorrowedPanel" role="tabpanel" aria-labelledby="booksborrowed-tab">

                        <!-- booklist table -->
                        <table id="borrowedBookTable" class="table table-striped table-bordered table-dark text-center">
                            <thead>
                                <tr>
                                    <th colspan="7">
                                        <h2>Borrowed Books</h2>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="7">
                                    <input type="text" class="form-control" id="searchBorrowedBook" name="borrowSearch" placeholder="Search: Title, Author or Library Section" />
                                    </th>
                                </tr>
                                <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>Genre</th>
                                    <th>Library Section</th>
                                    <?php if(Auth::user()->role_id == 1): ?>
                                        <th>Book Status</th>
                                        <th>User</th>
                                    <?php endif; ?>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(Auth::user()->role_id == 1): ?>
                                    <?php if(( count(\App\Book::where("status_id", "!=", 1)->get()) ) > 0): ?>
                                        <?php $__currentLoopData = \App\Book::where("status_id", "!=", 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td data-id="t<?php echo e($book->id); ?>"><?php echo e($book->title); ?></td>
                                                <td data-id="a<?php echo e($book->id); ?>"><?php echo e($book->author); ?></td>
                                                <td data-id="g<?php echo e($book->id); ?>"><?php echo e($book->genre->genre); ?></td>
                                                <td data-id="sec<?php echo e($book->id); ?>"><?php echo e($book->section->section); ?></td>
                                                <td><?php echo e($book->status->status); ?></td>
                                                <td>
                                                    <?php if(!empty($book->user_id) || $book->user_id != null): ?>
                                                        <?php echo e(ucwords($book->user->name)); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <button class="btn btn-primary" onclick="openEditModal(<?php echo e($book->id); ?>, <?php echo e($book->genre->id); ?>, <?php echo e($book->section->id); ?>, <?php echo e($book->status->id); ?>)">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7">No borrowed book/s</td>
                                        </tr>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <?php if(( count(\App\Book::where("user_id", Auth::user()->id)->get()) ) > 0): ?>
                                        <?php $__currentLoopData = \App\Book::where("user_id", Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td data-id="t<?php echo e($book->id); ?>"><?php echo e($book->title); ?></td>
                                                <td data-id="a<?php echo e($book->id); ?>"><?php echo e($book->author); ?></td>
                                                <td data-id="g<?php echo e($book->id); ?>"><?php echo e($book->genre->genre); ?></td>
                                                <td data-id="sec<?php echo e($book->id); ?>"><?php echo e($book->section->section); ?></td>
                                                <td>
                                                    <button class="btn btn-primary" onclick='openReturnModal(<?php echo e($book->id); ?>)'>
                                                        Return
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5">No borrowed book/s</td>
                                        </tr>
                                    <?php endif; ?>
                                    
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- end of booklist table -->
                    </div>
                    <!-- end of borrowed books panel -->
                </div>
                <!-- end of tab content -->

            </div>
            <!-- End of card-body -->
        </div>
        <!-- End of card -->

        <!-- Add Book Modal -->
        <div class="modal fade" id="addBookModal" tabindex="-1" role="dialog" aria-labelledby="addBookModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBookModalLabel">Add New Book</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="/addNewBook" method="POST">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group mb-3">
                                <label for="addBookTitle">Book Title</label>
                                <input id="addBookTitle" type="text" class="form-control" name="title" placeholder="Eg. Harry Potter and the Philosopher's Stone" />
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="addBookAuthor">Book Author</label>
                                <input id="addBookAuthor" type="text" class="form-control" name="author" placeholder="Eg. J. K. Rowling" />
                            </div>

                            <div class="form-group mb-3">
                                <label for="addBookGenre">Book Genre</label>
                                <select id="addBookGenre" class="form-control" name="genre">
                                    <option value="0" selected disabled>Select book genre</option>
                                    <?php $__currentLoopData = \App\Genre::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->genre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group mb-3">
                                <label for="addBookLibrarySection">Library Section</label>
                                <select id="addBookLibrarySection" class="form-control" name="section">
                                    <option value="0" selected disabled>Select library section</option>
                                    <?php $__currentLoopData = \App\Section::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->section); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="modal-footer">
                                <button id="btnSaveBook" type="submit" class="btn btn-success">Save</button>
                                <button id="btnCancelAddBook" type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- End of Add Book Modal -->

        <!-- Edit Book Modal -->
        <div class="modal fade" id="editBookModal" tabindex="-1" role="dialog" aria-labelledby="editBookModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editBookModalLabel">Update Book Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="editBookForm" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>


                            <div class="form-group mb-3">
                                <label for="editBookTitle">Book Title</label>
                                <input id="editBookTitle" type="text" class="form-control" name="title" />
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="editBookAuthor">Book Author</label>
                                <input id="editBookAuthor" type="text" class="form-control" name="author" />
                            </div>

                            <div class="form-group mb-3">
                                <label for="editBookGenre">Book Genre</label>
                                <select id="editBookGenre" class="form-control" name="genre">
                                    <option value="0" selected disabled>Select book genre</option>
                                    <?php $__currentLoopData = \App\Genre::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($genre->id); ?>" class="genres"><?php echo e($genre->genre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group mb-3">
                                <label for="editBookLibrarySection">Library Section</label>
                                <select id="editBookLibrarySection" class="form-control" name="section">
                                    <option value="0" selected disabled>Select library section</option>
                                    <?php $__currentLoopData = \App\Section::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->id); ?>" class="sections"><?php echo e($section->section); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div id="bookReturned" class="form-group mb-3">
                            </div>

                            <div class="modal-footer">
                                <button id="btnSaveBook" type="submit" class="btn btn-success mr-3">Save</button>
                                <button id="btnCancelAddBook" type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Edit Book Modal -->

        <!-- Delete Book Modal -->
        <div class="modal fade" id="deleteBookModal" tabindex="-1" role="dialog" aria-labelledby="deleteBookModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteBookModalLabel">Confirm delete</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="deleteBookForm" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>


                            <h5 class="text-center py-3">Are you sure you want to remove this book?</h5>

                            <div class="text-right my-3">
                                <button id="btnYesDeleteBook" type="submit" class="btn btn-success mr-3">Yes</button>
                                <button id="btnNoDeleteBook" type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- End of Delete Book Modal -->

        <!-- Borrow Book Modal -->
        <div class="modal fade" id="borrowBookModal" tabindex="-1" role="dialog" aria-labelledby="borrowBookModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="borrowBookModalLabel">Confirm borrow this book</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="borrowBookForm" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>


                            <h5 class="text-center py-3"></h5>

                            <div class="text-right my-3">
                                <button id="btnYesBorrowBook" type="submit" class="btn btn-success mr-3">Yes</button>
                                <button id="btnNoBorrowBook" type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- End of Borrow Book Modal -->

        <!-- Return Book Modal -->
        <div class="modal fade" id="returnBookModal" tabindex="-1" role="dialog" aria-labelledby="returnBookModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="returnBookModalLabel">Confirm return this book</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="returnBookForm" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>


                            <h5 class="text-center py-3"></h5>

                            <div class="text-right my-3">
                                <button id="btnYesReturnBook" type="submit" class="btn btn-success mr-3">Yes</button>
                                <button id="btnNoReturnBook" type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- End of Return Book Modal -->
    </div>
    <!-- End of Container -->

    <script>
        $(".pagination").addClass("justify-content-center");
        $(".pagination li").addClass("page-item");
        $(".pagination li:first-child span").html("Previous");
        $(".pagination li:last-child span").html("Next");
        $(".pagination li:first-child a").html("Previous");
        $(".pagination li:last-child a").html("Next");
        $(".pagination li a").addClass("page-link");
        $(".pagination li span").addClass("page-link");

        function openEditModal(id, genre_id, section_id, status_id) {
            let title = $("td[data-id='t"+id+"']").text();
            let author = $("td[data-id='a"+id+"']").text();
            
            $(".genres").each(function(){
                $(this).attr("selected", false);

                if($(this).val() == genre_id) {
                    $(this).attr("selected", true);
                }
            });

            $(".sections").each(function(){
                $(this).attr("selected", false);

                if($(this).val() == section_id) {
                    $(this).attr("selected", true);
                }
            });
            
            if((status_id == 2) || (status_id == 3)) {
                $("#bookReturned").html('<label for="editBookLibrarySection">Has this book returned?</label>' +
                                '<div>' +
                                    '<div class="form-check form-check-inline">' +
                                        '<input class="form-check-input" type="radio" name="status" id="bookAvailable" value="1">' +
                                        '<label class="form-check-label" for="inlineRadio1">Yes</label>' +
                                    '</div>' +
                                    '<div class="form-check form-check-inline">' +
                                        '<input class="form-check-input" type="radio" name="status" id="bookUnavailable" value="'+status_id+'">' +
                                        '<label class="form-check-label" for="inlineRadio2">No</label>' +
                                    '</div>' +
                                '</div>');
            } else {
                $("#bookReturned").html("");
            }
            

            $("#editBookTitle").val(title);
            $("#editBookAuthor").val(author);
            
            $("#editBookForm").attr("action", "/editBook/"+id+"/"+status_id);
            $("#editBookModal").modal("show");
        }

        function openDeleteModal(id) {
            $("#deleteBookForm").attr("action", "/deleteBook/"+id);
            $("#deleteBookModal").modal("show");
        }

        function openBorrowModal(book_id) {
            let bookTitle = $("td[data-id='t"+book_id+"']").text();
            // alert(bookTitle);
            $("#borrowBookForm h5").html("Are you sure you want to borrow " + bookTitle + "?");
            $("#borrowBookForm").attr("action", "/borrowBook/"+book_id+"/"+bookTitle);
            $("#borrowBookModal").modal("show");
        }

        function openReturnModal(book_id) {
            let bookTitle = $("td[data-id='t"+book_id+"']").text();
            $("#returnBookForm h5").html("Are you sure you want to return " + bookTitle + "?");
            $("#returnBookForm").attr("action", "/returnBook/"+book_id+"/"+bookTitle);
            $("#returnBookModal").modal("show");
        }

        $('#search').on('keyup',function(){
            let value = $(this).val();
            // alert(value);
            $.ajax({
                type: 'get',
                url: '/search',
                data:{'search':value},        
                success: function(data){
                    $('#booklistTable tbody').html(data);
                }
            });
        });

        $("#searchBorrowedBook").on('keyup', function() {
            let getValue = $(this).val();
            $.ajax({
                type: 'get',
                url: '/borrowSearch',
                data: {'borrowSearch':getValue},
                success: function(data) {
                    $("#borrowedBookTable tbody").html(data);
                }
            });
        });
    </script>
    <script type="text/javascript">
        $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
    </script>
    <!-- https://stackoverflow.com/questions/13386774/using-eloquent-orm-in-laravel-to-perform-search-of-database-using-like/26452953 -->
    <!-- https://laracasts.com/discuss/channels/laravel/filtering-data-using-drop-down-onchange-event?page=1 -->
    <!-- https://www.w3schools.com/jquery/event_keyup.asp -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>