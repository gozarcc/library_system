<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\User;
use \App\Book;
use Session;
use Auth;


class BookController extends Controller {
    public function showBooks() {
        $books = Book::where("status_id", 1)
        ->orderBy("title", "asc")
        ->paginate(10);

        return view("/library/books", compact("books"));
        // dd($books);
    }

    public function addNewBook(Request $request) {
        $add_book = new Book;

        $rules = array(
            'title' => 'required',
            'author' => 'required',
            'genre' => 'required',
            'section' => 'required'
        );
        $this->validate($request, $rules);

        $add_book->title = $request->title;
        $add_book->author = $request->author;
        $add_book->genre_id = $request->genre;
        $add_book->section_id = $request->section;
        $add_book->status_id = 1;
        $add_book->save();

        Session::flash("success_message", "New book successfully added!");
        return redirect("/books");
    }

    public function editBook(Request $request, $id, $status_id) {
        $edit_book = Book::find($id);

        $rules = array(
            'title' => 'required',
            'author' => 'required',
            'genre' => 'required',
            'section' => 'required'
        );
        $this->validate($request, $rules);

        $edit_book->title = $request->title;
        $edit_book->author = $request->author;
        $edit_book->genre_id = $request->genre;
        $edit_book->section_id = $request->section;
        // $edit_book->status_id = $status_id;
        if (!empty($request->status) || $request->status != null) {
            $edit_book->status_id = $request->status;
        } else {
            $edit_book->status_id = $status_id;
        }
        $edit_book->save();

        Session::flash("success_message", "Changes saved!");
        return redirect("/books");
    }

    public function deleteBook($id) {
        $delete_book = Book::find($id);
        // dd($delete_book);
        $delete_book->delete();

        Session::flash("success_message", "Book was successfully deleted!");
        return redirect("/books");
    }

    public function borrowBook($book_id, $bookTitle) {
        $borrow_book = Book::find($book_id);
        // dd($borrow_book);
        $borrow_book->status_id = 2;
        $borrow_book->user_id = Auth::user()->id;
        $borrow_book->save();

        Session::flash("success_message", "You successfully borrowed $bookTitle!");
        return redirect("/books");
    }

    public function returnBook($book_id, $bookTitle) {
        $return_book = Book::find($book_id);
        $return_book->status_id = 3;
        $return_book->user_id = null;
        $return_book->save();

        Session::flash("success_message", "You successfully returned $bookTitle!");
        return redirect("/books");
    }

    public function search(Request $request) {
        if($request->ajax()) {
            $output="";
            $books= Book::join("genres", "books.genre_id", "=", "genres.id")
            ->join("sections", "books.section_id", "=", "sections.id")
            ->join("statuses", "books.status_id", "=", "statuses.id")
            ->select("books.*", "genres.*", "sections.*", "statuses.*")
            ->where("books.status_id", 1)
            ->where('books.title','LIKE','%'.$request->search.'%')
            ->orWhere("books.status_id", 1)
            ->where('books.author','LIKE','%'.$request->search.'%')
            ->orWhere("books.status_id", 1)
            ->where('sections.section','LIKE','%'.$request->search.'%')
            ->get();
        
            // if($books) {
            if ($books->count() > 0) {
                foreach ($books as $key => $book) {
                    $output.='<tr>'.
                        '<td>'.$book->title.'</td>'.
                        '<td>'.$book->author.'</td>'.
                        '<td>'.$book->genre.'</td>'.
                        '<td>'.$book->section.'</td>';

                        if (Auth::user()->role_id == 1) {
                            $output .= '<td>'.$book->status.'</td>';
                        }
                        
                        $output .= '<td>';
                            if (Auth::user()->role_id == 1) {
                                $output .= '<button class="btn btn-primary mr-2" onclick="openEditModal('.$book->id.', '.$book->genre_id.', '.$book->section_id.', '.$book->status_id.')">' .
                                        '<i class="fas fa-edit"></i>' .
                                    '</button>' .

                                    '<button class="btn btn-danger" onclick="openDeleteModal('.$book->id.')">' .
                                        '<i class="fas fa-trash-alt"></i>' .
                                    '</button>';
                            } else {
                                $output .= '<button class="btn btn-primary" onclick="openBorrowModal('.$book->id.', '.$book->title.')">' .
                                    'Borrow' .
                                '</button>';
                            }
                        $output .= '</td>' .
                    '</tr>';
                }
            } else {
                $output .= '<tr>';
                    if(Auth::user()->role_id == 1) {
                        $output .= '<td colspan="7">No record found</td>';
                    } else {
                        $output .= '<td colspan="5">No record found</td>';
                    }
                $output .='</tr>';
            }
                return Response($output);
            // }
        }
    }

    public function borrowSearch(Request $request) {
        if ($request->ajax()) {
            $output = "";
            
            // this is for the search if logged in as admin
            $borrowed_books = Book::join("genres", "books.genre_id", "=", "genres.id")
            ->join("sections", "books.section_id", "=", "sections.id")
            ->join("statuses", "books.status_id", "=", "statuses.id")
            ->select("books.*", "genres.genre", "sections.section", "statuses.status")
            ->where("books.status_id", "!=", 1)
            ->where('books.title', 'LIKE', '%'.$request->borrowSearch.'%')
            ->orWhere("books.status_id", "!=", 1)
            ->where('books.author', 'LIKE', '%'.$request->borrowSearch.'%')
            ->orWhere("books.status_id", "!=", 1)
            ->where('sections.section', 'LIKE', '%'.$request->borrowSearch.'%')
            ->get();
            // dd($borrowed_books);

            // this is for the search if logged in as user
            $user_borrowed_books = Book::join("genres", "books.genre_id", "=", "genres.id")
            ->join("sections", "books.section_id", "=", "sections.id")
            ->select("books.*", "genres.genre", "sections.section")
            ->where("books.user_id", Auth::user()->id)
            ->where('books.title', 'LIKE', '%'.$request->borrowSearch.'%')
            ->orWhere("books.user_id", Auth::user()->id)
            ->where('books.author', 'LIKE', '%'.$request->borrowSearch.'%')
            ->orWhere("books.user_id", Auth::user()->id)
            ->where('sections.section', 'LIKE', '%'.$request->borrowSearch.'%')
            ->get();

            if (Auth::user()->role_id == 1) {
                if (count($borrowed_books) > 0) {
                    foreach ($borrowed_books as $key => $book) {
                        $output .= '<tr>' .
                            '<td data-id="t'.$book->id.'">'.$book->title.'</td>' .
                            '<td data-id="a'.$book->id.'">'.$book->author.'</td>' .
                            '<td data-id="g'.$book->id.'">'.$book->genre.'</td>' .
                            '<td data-id="sec'.$book->id.'">'.$book->section.'</td>' .
                            '<td>'.$book->status.'</td>' .
                            '<td>';
                                if(!empty($book->user_id) || $book->user_id != null) {
                                    $user_name = Book::join("users", "books.user_id", "=", "users.id")
                                    ->select("users.name")
                                    ->where("books.id", $book->id)
                                    ->get();

                                    foreach ($user_name as $key => $user) {
                                        $output .= ucwords($user->name);
                                    }
                                } else {
                                    $output .= " ";
                                }
                            $output .= '</td>' .
                            '<td>' .
                                '<button class="btn btn-primary" onclick="openEditModal('.$book->id.', '.$book->genre_id.', '.$book->section_id.', '.$book->status_id.')">' .
                                    '<i class="fas fa-edit"></i>' .
                                '</button>' .
                            '</td>' .
                        '</tr>';
                    }
                } else {
                    $output .= '<tr>' .
                        '<td colspan="7">No record found</td>' .
                    '</tr>';
                }
                return Response($output);

            } else {
                if (count($user_borrowed_books) > 0) {
                    foreach ($user_borrowed_books as $key => $book) {
                        $output .= '<tr>' .
                            '<td data-id="t'.$book->id.'">'.$book->title.'</td>' .
                            '<td data-id="a'.$book->id.'">'.$book->author.'</td>' .
                            '<td data-id="g'.$book->id.'">'.$book->genre.'</td>' .
                            '<td data-id="sec'.$book->id.'">'.$book->section.'</td>' .
                            '<td>' .
                                '<button class="btn btn-primary" onclick="openReturnModal('.$book->id.')">' .
                                    'Return' .
                                '</button>' .
                            '</td>' .
                        '</tr>';
                    }
                } else {
                    $output .= '<tr>' .
                        '<td colspan="5">No record found</td>' .
                    '</tr>';
                }
                return Response($output);
            }
        }
    }
}
