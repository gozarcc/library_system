<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    public function status() {
        return $this->belongsTo("\App\Status");
    }
    
    public function genre() {
        return $this->belongsTo("\App\Genre");
    }

    public function section() {
        return $this->belongsTo("\App\Section");
    }

    public function user() {
        return $this->belongsTo("\App\User");
    }
}
