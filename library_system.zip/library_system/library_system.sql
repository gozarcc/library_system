-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2018 at 08:27 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `genre_id` int(10) UNSIGNED DEFAULT NULL,
  `section_id` int(10) UNSIGNED DEFAULT NULL,
  `status_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `genre_id`, `section_id`, `status_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Harry Potter and the Philosopher\'s Stone', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 18:44:01', '2018-09-16 08:47:13'),
(2, 'Harry Potter and the Chamber of Secrets', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 18:49:37', '2018-09-16 08:47:04'),
(3, 'Harry Potter and the Prisoner of Azkaban', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 19:26:50', '2018-09-16 08:47:20'),
(4, 'Harry Potter and the Goblet of Fire', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 19:28:24', '2018-09-16 08:49:36'),
(5, 'Harry Potter and the Order of the Phoenix', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 19:28:53', '2018-09-16 08:49:22'),
(6, 'Harry Potter and the Half-Blood Prince', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 19:29:15', '2018-09-16 08:49:33'),
(7, 'Harry Potter and the Deathly Hallows', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 19:29:39', '2018-09-16 08:49:29'),
(8, 'Harry Potter and the Cursed Child', 'J. K. Rowling', 4, 5, 2, 2, '2018-09-15 19:33:02', '2018-09-16 08:49:25'),
(9, 'The Lord of the Rings: The Fellowship of the Ring', 'J. R. R. Tolkien', 4, 5, 1, NULL, '2018-09-15 19:42:12', '2018-09-15 19:42:12'),
(10, 'The Lord of the Rings: The Two Towers', 'J. R. R. Tolkien', 4, 5, 1, NULL, '2018-09-15 19:43:29', '2018-09-15 19:43:29'),
(11, 'The Lord of the Rings: The Return of the King', 'J. R. R. Tolkien', 4, 5, 1, NULL, '2018-09-15 19:44:24', '2018-09-15 19:44:24'),
(12, 'The Hobbit, or There and Back Again', 'J. R. R. Tolkien', 4, 5, 1, NULL, '2018-09-15 19:53:37', '2018-09-15 19:53:37'),
(13, 'Twilight', 'Stephenie Meyer', 2, 5, 1, NULL, '2018-09-15 19:57:15', '2018-09-16 09:19:25'),
(14, 'New Moon', 'Stephenie Meyer', 2, 5, 1, NULL, '2018-09-15 19:57:35', '2018-09-16 09:19:16'),
(15, 'Eclipse', 'Stephenie Meyer', 2, 5, 1, NULL, '2018-09-15 19:57:53', '2018-09-16 09:19:34'),
(16, 'Breaking Dawn', 'Stephenie Meyer', 2, 5, 1, NULL, '2018-09-15 19:58:13', '2018-09-16 09:19:07'),
(17, 'The Notebook', 'Nicholas Sparks', 2, 5, 1, NULL, '2018-09-15 19:59:54', '2018-09-15 19:59:54'),
(18, 'Me Before You', 'Jojo Moyes', 2, 5, 1, NULL, '2018-09-15 20:02:37', '2018-09-16 09:18:46'),
(19, 'After You', 'Jojo Moyes', 2, 5, 1, NULL, '2018-09-15 20:03:30', '2018-09-16 09:18:35');

-- --------------------------------------------------------

--
-- Table structure for table `genres`
--

CREATE TABLE `genres` (
  `id` int(10) UNSIGNED NOT NULL,
  `genre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `genres`
--

INSERT INTO `genres` (`id`, `genre`, `created_at`, `updated_at`) VALUES
(1, 'Horror', NULL, NULL),
(2, 'Romance', NULL, NULL),
(3, 'Thriller', NULL, NULL),
(4, 'Fantasy', NULL, NULL),
(5, 'Poetry', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_09_11_044730_create_statuses_table', 1),
(2, '2014_09_12_044718_create_roles_table', 1),
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2014_10_12_100000_create_password_resets_table', 1),
(5, '2018_08_07_053346_create_genres_table', 1),
(6, '2018_08_08_053412_create_sections_table', 1),
(7, '2018_09_05_034056_create_books_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Admin', NULL, NULL),
(2, 'User', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `section` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `section`, `created_at`, `updated_at`) VALUES
(1, 'Circulation', NULL, NULL),
(2, 'Periodical Section', NULL, NULL),
(3, 'General Reference', NULL, NULL),
(4, 'Children\'s Section', NULL, NULL),
(5, 'Fiction', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Available', NULL, NULL),
(2, 'Borrowed', NULL, NULL),
(3, 'Returned', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Charlene Gozar', 'cha@gmail.com', '$2y$10$W2t7PNPkWafjsc4bb6QzMOpcRh0qPJU9LtMblh1OlYtPGqnOb6ZSK', 1, 'bt5eM8UwHOAtwAjc0FRBbWnd6Vb0e6PdbvmJRnVbl0VKcB5h7dhxGShcEFC3', '2018-09-15 18:33:00', '2018-09-15 18:33:00'),
(2, 'Judy Anne Pontiveros', 'judy@gmail.com', '$2y$10$HE1l8szJHSuyUbl1JxETpeTl.rnAy33URnVCJSOufZYU/7gQwK7T6', 2, 'cFqV2IAreffR4wnaSkEZdf2f8XNp6IFmRcLUinxT6SuekumIF2SKvThXz9YW', '2018-09-15 18:46:43', '2018-09-15 18:46:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `books_genre_id_foreign` (`genre_id`),
  ADD KEY `books_section_id_foreign` (`section_id`),
  ADD KEY `books_status_id_foreign` (`status_id`),
  ADD KEY `books_user_id_foreign` (`user_id`);

--
-- Indexes for table `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `genres`
--
ALTER TABLE `genres`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `books_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `books_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `books_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
